
import React from "react";
import ReactDOM from "react-dom/client";
import ShowroomApp from "./App";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ShowroomApp />
  </React.StrictMode>
);
