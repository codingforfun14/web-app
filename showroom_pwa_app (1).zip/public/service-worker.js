// Placeholder for service worker
self.addEventListener('install', () => self.skipWaiting());